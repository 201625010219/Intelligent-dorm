#ifndef __MAINTASK_H
#define __MAINTASK_H

#include "GUI.h"
#include "TEXT.h"

void MainTask(void);

#endif /* __MAINTASK_H */
